//
//  LocalisationView.swift
//  Association_Project
//
//  Created by Wendy ALPHANOR on 10/12/2024.
//

import SwiftUICore
import SwiftUI
import MapKit
import CoreLocation


struct LocalisationView: View {
    var body: some View {
        VStack {
            Text("Localisation")
                .font(.largeTitle)
                .padding()
            Spacer()
        }
    }
}


