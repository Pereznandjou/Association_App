//
//  Association_ProjectTests.swift
//  Association_ProjectTests
//
//  Created by Wendy ALPHANOR on 10/12/2024.
//

import Testing
@testable import Association_Project

struct Association_ProjectTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
